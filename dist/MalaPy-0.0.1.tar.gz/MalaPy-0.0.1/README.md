# MalaPy

MalaPy is an unofficial Python interface for requesting lists of associated diseases for genes from MalaCards (https://www.malacards.org/).

To use it, you may either use mala_checker() for individual gene names, or check_gene_list() for a list of genes of unlimited length. 
